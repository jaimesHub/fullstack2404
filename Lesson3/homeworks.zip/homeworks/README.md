# Homeworks 14/05/2024

# Exercise 1
- use internal style
- use inline css

# Exercise 2
- use internal style

# Exercise 3
- use internal style
- use inline css

# Exercise 4
- use internal css

# Exercise 5
- use internal css

# Exercise 6
- use external css

# Exercise 7
- use external css

# Exercise 8
- use external css