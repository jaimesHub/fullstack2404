// Tính tổng các số chẵn trong đoạn [-30, 50].
let result = 0
for (let i = -30; i <= 50; i++) {
    result += i;
}
console.log(`result = ${result}`);