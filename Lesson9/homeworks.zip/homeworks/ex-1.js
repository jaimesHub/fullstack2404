// In ra dãy số từ 1 đến 500.
for(let i = 1; i <= 500; i++) {
    console.log(`i = ${i}`);
}