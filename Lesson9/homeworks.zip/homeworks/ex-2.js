// In ra các số chia hết cho 2 và 3 từ 1 đến 300.
for (let i = 1; i <= 300; i++) {
    if(i % 2 === 0 && i % 3 === 0) {
        console.log(`i = ${i}`);
    }
}